import Foundation

let pizzaInInches: Int = 10

//Computed prop has to be a data type mentioned
//Computed properties has to be Var not let
// Getters
var numberOfSlices: Int {
    pizzaInInches - 4
}

print(numberOfSlices)




//*****   Getters and Setters   ***********//

let pizzaInInches2:Int = 12

var numberOfSlices2: Int {
    get {
        return pizzaInInches2 - 4
    }
    set {
        print("numberOfSlices2 now has a new value which is \(newValue)")
    }
}

numberOfSlices2 = 12



//**** Computed Properties *****//


let pizzaInches3: Int = 16
var numberOfPeople3: Int = 12
let slicesPerPerson: Int = 4

var numberOfSlices3: Int {
    get {
        return pizzaInches3 - 4
    }
}

var numberOfPizza3: Int {
    get {
        let numberOfPeopleFedPerPizza = numberOfSlices3 / slicesPerPerson
        return numberOfPeople3 / numberOfPeopleFedPerPizza
    }
    set {
        let totalSlices = numberOfSlices3 * newValue
        numberOfPeople3 = totalSlices / slicesPerPerson
    }
}
numberOfPizza3 = 4
print(numberOfPeople3)



//**** Observed Properties *****//
//triggers code when a property's value is changed



var pizzaInInches4: Int = 10 {
    willSet {
        
    }
    didSet {
        if pizzaInInches4 >= 18 {
            print("Invalid size")
            pizzaInInches4 = 18
        }
    }
}
pizzaInInches4 = 33
print(pizzaInInches4)
