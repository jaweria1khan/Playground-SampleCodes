

//----------Any, AnyObject, NSObject----------
//Sometimes you want a different range of data types, you dont want specific data types, you want flexibilty


// Any --> All objects derived from classes or struct or it can be any data type

//AnyObject (subclass of Any) Certain protocols that have an requirement where only object created from the  class can actually confirm to that protocol so that they might use that data type AnyObject in that way to limit things work to classes
//AnyObjects are restricts the objects that comes from classes





//NSObject object created from the NS foundation classes classes like Foundation object,NSnumber, file manager etc created by apple





import Foundation

class Animal {
    var name: String
    
    init(n: String) {
        name = n
    }
}
class Human : Animal {
    func code() {
        print("Typing away...")
    }
}

class Fish: Animal {
    func breathUnderWater() {
        print("Breathing under water.")
    }
}

let angela = Human(n: "Angela Yu")
let jack = Human(n: "Jack Baur")
let nemo = Fish(n: "Nemo")
let num = 12

//arrray of objects for ANY
let neighbours: [Any] = [angela, jack, nemo, num] //Any allows us to mix any object


//let angela = Human(n: "Angela Yu")
//let jack = Human(n: "Jack Baur")
//let nemo = Fish(n: "Nemo")
//let num = 12
//
//let neighbours: [AnyObject] = [angela, jack, nemo, "num"] // giving error on "num" because anyObject doesnot allow structs






//NSObject doesnot allow structs
let word: NSString = "abc"
let numb: NSNumber = 13

let neighbour: [NSObject] = [numb, word]
