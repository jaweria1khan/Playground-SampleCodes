import Foundation

class Animal {
    var name: String
    
    init(n: String) {
        name = n
    }
}
class Human : Animal {
    func code() {
        print("Typing away...")
    }
}

class Fish: Animal {
    func breathUnderWater() {
        print("Breathing under water.")
    }
}

let angela = Human(n: "Angela Yu")
let jack = Human(n: "Jack Baur")
let nemo = Fish(n: "Nemo")

let neighbours = [angela, jack, nemo]

//let neighbour1 = neighbours[0]
//let myDouble = 0.0
//let myDoubleAsAnInt = Int(myDouble)

//-----TYPE CAST "IS"-----
//-----------Type CHECKING-------
if jack is Human {
    print("First Neighbour is Human")
}
if neighbours[2] is Human {
    print("First neighbour is human")
}

func findNemo(from animals: [Animal]) {
    for animal in animals {
        if animal is Fish {
            print(animal.name)
    // forced down cast as!
            let fish = animal as! Fish
            fish.breathUnderWater()
            let animalFish = fish as Animal //up casting
        }
    }
}
findNemo(from: neighbours)

let fish = neighbours[1] as? Fish
fish?.breathUnderWater() // optional chaining

// OR optional binding

if let fish = neighbours[1] as? Fish {
    fish.breathUnderWater()
} else {
    print("")
}
