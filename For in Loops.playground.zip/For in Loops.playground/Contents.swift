import Foundation

//let fruits: Set = ["Apple", "Peer", "Orange"] // a set contains many items prints randomly not in particular order in loop
let fruits: Array = ["Apple", "Peer", "Orange"] // array of fruits
let contacts = ["Adam": 1234, "James": 5678, "Amy": 987] // dict of contacts
let word = "twinkletwinklelittelstar" // string
let halfOpenRange = 1..<5 // half range operator excluding 5
let closedRange = 1...5 // closed range operator including 5


for fruit in fruits {
    print(fruit)
}

for person in contacts {
    //dict
    print(person.key)
    print(person.value)
}

for letter in word {
    print(letter)
}

for number in halfOpenRange {
    print(number)
}

for number  in closedRange {
    print(number)
}




var x = -1 ,y = 1, sum = 0;
    
for _ in 0..<10 {

sum = x+y;
x   = y;
y   = sum;

print(sum);
    
}



//--------------------------while loops-----------------------

var now = Date().timeIntervalSince1970
let oneSecondFromNow = now + 1

while now < oneSecondFromNow {
    now = Date().timeIntervalSince1970
    print("waiting...") //running so many times because these loops run very fast
}
