
import Foundation

let touple1 = ("JV", 12)

let touple2 = (name: "Jv", age: "12")

let touple3: (name: String, age: Int)
touple3 = (name: "JV", age: 21)

print("\(touple3.name) is \(touple3.age)")
